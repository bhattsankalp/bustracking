import React,{Component} from 'react'
import continents from './Continents.json'

function  Countries (props) {

 if(!props.showCountry)
  return <div >
        </div> 

  else return (
<div className="childSpace" >
  <div className="componentBody" onMouseLeave={props.hideCountries}>

    <header>
    <p className="title">Step 2</p>
    <label>Now, select a country </label>
    </header>

  <div className="List" >
  <input type="text" id = "country" 
  autoComplete = "off"
  onChange={e => props.showSuggestionCountries(e)}
  onClick={e => props.showSuggestionCountries(e)}
  />

  {props.showSuggestionCountry ?
    props.suggestionCountries.map (country => {
      if (country.name.toLowerCase().slice(0,props.inputCountry.length ) == props.inputCountry.toLowerCase() )
      return <div className="countryList">

      <input type='checkbox' id={country.name}
      checked={country.checked}
      onChange={(e) => props.showFlags(e,country)}
        /> {country.name}
      </div>
    
  }): null
  } 
  </div>
</div>
</div>
  )}

export default Countries