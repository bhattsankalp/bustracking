import React from 'react';
import './Homepage.css';
import { Card} from 'react-bootstrap';
import Topbar from '../Topbar'
import {withRouter,Link} from 'react-router-dom'

class Homepage  extends  React.Component {

   

render(){

return(
    < section className="graybackground">
           <Topbar />
    <div className="landingPage">
       <h5 className="subHeadings" sm={{span:2}}>Choose an Activity</h5>     
    <div className="homeTiles">
        <div className="col-3 ">
<Card  className="tileOrange" 
 onClick={e => this.props.history.push({pathname : "/allbuses"})
 } 
>

  <Card.Body>
  <img src="../allbuses.jpg" style={{width:100,height:100}} />
   
    <Card.Text className="whiteSubHeading">
    Get All Buses
    </Card.Text>
   
  </Card.Body>
</Card>
</div>


<div className="col-3 ">
<Card  className="tileGreen" 
onClick={e => this.props.history.push({pathname : "/testinghome"})
 } 
>

  <Card.Body>
  <img src="../busroute.png" style={{width:100,height:100}} />
    <Card.Text className="whiteSubHeading">
    Search Bus by route
    </Card.Text>
   
  </Card.Body>
</Card>
</div>


<div className="col-3 ">
<Card  className="tileRed" 
onClick={e => this.props.history.push({pathname : "/getBusStatus"})
 } 
>

  <Card.Body>
  <img src="../busid.png" style={{width:100,height:100}} />
    <Card.Text className="whiteSubHeading">
    Get Bus status by bus Id
    </Card.Text>
   
  </Card.Body>
</Card>
</div>



    </div>
    </div>
    </section>
)


}
}


export default withRouter(Homepage)

