

import React,{Component} from 'react'
import './Allbuses.css';
import { MDBDataTableV5, MDBTableBody, MDBTableHead } from 'mdbreact';
import { withRouter } from 'react-router-dom';
import Topbar from '../Topbar';
import {connect} from 'react-redux'
import {OverlayTrigger,Tooltip,Breadcrumb,Col} from 'react-bootstrap';

class Allbuses extends Component {

    constructor(){
        super()
        this.state={
            userData:{},
            site_id:"",
            site_name:"",
            site_URL: ""
        }
    }
componentDidMount(){
var rows
var columns
    
    
fetch('http://localhost:8000/getAllbuses')
.then(res => res.json())
.then((res) => {

    if(res[0]){

              columns = [
                { label: 'Bus Id',
                field: 'busId',
                width: 200,
               
              },
             { label: 'Route Id',
                    field: 'routeId',
                    width: 100,
                   
                  },
                  { label: 'Route',
                      field: 'route',
                      width: 200
                    }]

                    rows =  res.map(value => {
                      return({ 
                       
                        busId: value.bus.busId,
                        routeId : value.bus.routeId,
                        route : value.route.route
                         
                   })
                  }) 

                  this.setState({
                    userData: {
                      rows:rows,
                      columns:columns
                    },
                
                    showUserData:true
                  })
                  }
})
}

    render(){
return(
    <div className="graysectionBg">
    <Topbar />

<Breadcrumb>
<Breadcrumb.Item href="/homePage">Home</Breadcrumb.Item>
<Breadcrumb.Item active>Get All Buses</Breadcrumb.Item>
</Breadcrumb>
{this.state.showUserData ? 
<div className="userResponseContent" >
<h5 className="subHeadings">All Buses</h5>



<Col sm={{span:8,offset:2}}>
<MDBDataTableV5
hover
striped 
bordered
style={{textAlign:'center'}}
 pagingTop
 searchTop
 scrollX
 scrollY

 maxHeight="25rem"
 searchBottom={false}
 data={this.state.userData}

/>
</Col>
</div>
: null }
</div>
)
    }
}

const mapStateToProps = (state) => {

    return ({
    
    userName : state.userSelect.userName
    })
  }

    export default withRouter(connect(mapStateToProps) (Allbuses))