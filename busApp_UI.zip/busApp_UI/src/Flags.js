import React from 'react'

function  Flags(props) {

  if (!props.showFlag) {
    return  <div >
    </div> 
    }
  else 
  return (
  <div className="childSpace" > 
    <div  className="componentBody">
  
    <header>
    <p className="title">Selected Flags</p>
    </header>
    
    <div className = "Flaglist">
    {props.flags.map(val => {
      
      return <span id="flags" >{val.flag}</span>
    })
    }

    </div>
   <button onClick={props.clearFlags}><h3>Clear Flags</h3></button>
    </div>
  
</div>
)
}
export default Flags
