import React,{Component} from'react'
import {setUser} from './actions/setUser'
import {connect} from 'react-redux'
import {withRouter,Link} from 'react-router-dom'
import {FaUserCog,FaUnlockAlt,FaUserPlus} from "react-icons/fa";
import { IoMdLogIn } from "react-icons/io";
import { Button,Form} from 'react-bootstrap'
import Topbar from './Topbar'
import RegisterUser from './components/RegisterUser'

class LoginPage extends Component{
 constructor(){
     super()
     this.state={
         userName:"",
         password: "",
         userType: "",
         showLogin:true
     }
     this.handleChange = this.handleChange.bind(this)
     this.getUserType=this.getUserType.bind(this)
 }

componentDidMount(){
    var Link
    if(this.props.userType ) {

    
         Link ="/homePage"
      } 
     
     
     else {Link ="/"}

     this.props.history.push({pathname: Link}) 
     

}

    
 handleChange = e => {
    this.setState({ [e.target.name]: e.target.value })
       
     }

     showRegister =() => {
      this.setState({
        showLogin:false
      })
     }

 getUserType(){
  var Link
  this.props.setUser(this.state.userName,this.state.password)
  if(this.props.userType ) {
Link ="/homePage"
 } 

else {Link ="/"}

this.props.history.push({pathname: "/homePage"}) 

 }


render(){
return(

<section className="loginPage ">
    <Topbar />
    {this.state.showLogin ? 
<form className="container loginForm">
<h5 className="loginHeading"><IoMdLogIn className="contacticons"/>&nbsp;Login</h5>
<Form.Group controlId="userName">
    <Form.Label ><FaUserCog className="icons"/>&nbsp;User Name</Form.Label>
    <Form.Control type="text" placeholder="Enter UserName"  name="userName"
     autoComplete="off"
     autoFocus
     onChange={e => this.handleChange(e)}
     value={this.state.userName}/>
   
   
  </Form.Group>

  <Form.Group controlId="password">
    <Form.Label ><FaUnlockAlt className="icons"/>&nbsp;Password</Form.Label>
    <Form.Control type="password" placeholder="Enter Password"  name="password"
     autoComplete="off"
     onChange={e => this.handleChange(e)}
     value={this.state.password}/>
   
   
  </Form.Group>
  <Button  className="btn btn-primary ml-0"  
size="lg" block
onClick={e => this.getUserType(e)}>&nbsp;&nbsp;Login&nbsp;&nbsp;</Button >

<div className="registerLink">
<a as={Link} onClick={e =>  this.showRegister()  } ><FaUserPlus className="icons"/> <u>Register</u></a>
</div>
</form>
:
 <RegisterUser />
    }
</section>


        )
 
    }
 
}

const mapStateToProps = (state) => {
    return ({
      userName: state.userSelect.userName,
      userType : state.userSelect.userType
    })
  }

  const mapDispatchToProps = (dispatch) => {
return({
    setUser : (userName,password) => {
        dispatch(setUser(userName,password))
    } 
})

  }
 
export default withRouter(connect(mapStateToProps,mapDispatchToProps) (LoginPage))


