import React, { Component } from 'react'
import continents from './Continents.json'


class Continent extends Component {

  constructor() {
    super()
    this.state = {
      data: [],
      continents: [],
      selectedContinent: ''
    }
    this.showContinents=this.showContinents.bind(this)
    this.hideContinents= this.hideContinents.bind(this)
  }

  componentDidMount() {
    this.setState({
      data: continents,
      continents: continents.map(val => val.continent)

    })
  }

  showContinents (e){
    var inputVal = e.target.value
    var inputLength = e.target.value.length
    this.setState({
      showContinent : true,
      suggestionContinents : this.state.continents.filter (val => {
                         return val.toLowerCase().slice(0,inputLength) == inputVal
      })
    })
    
    }
  
  hideContinents(e){
  
   this.setState({
      showContinent : false
   }) 
  }

    getCountries(continent) {
      this.setState({
        showCountry : true,
        showContinent : false,
        selectedContinent : continent,
        
      })
      
      this.props.setCountries(continent)
      }
      

  render() {

    return (
   <div className="childSpace" >
      <div className="componentBody">
      
       <header>
        <p className="title">Step 1</p>
        <label>Select a continent: </label><br></br>
       </header>
        
        <div className="List"    onMouseLeave= {e => this.hideContinents()}>
        <input type="text" 
        autoComplete = "off"
         onChange={e => this.showContinents(e)}
        onClick={e => this.showContinents(e)}  />

        {this.state.showContinent ? this.state.suggestionContinents.map (val => {
          return <li id="continentListitem" onClick = {e => this.getCountries(val)}  > {val}</li>
        })
        : null
         }
        </div>
       

        {this.state.showCountry ?
        <div  className="Continent">
          <label>You Selected </label>
          <p className="title">{this.state.selectedContinent}</p>
          </div>
          : null}

        
     
      </div>
      </div>
    )
  }





}

export default Continent

