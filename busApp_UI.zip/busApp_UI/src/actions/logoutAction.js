export const logoutAction = () => (dispatch) => {


    return dispatch({
        type: "LOGOUT"
       
    })



}