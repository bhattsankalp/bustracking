export const setUser = (userName,password) => (dispatch) => {


    var requestData = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userName:userName ,
            password: password
        })
      }
    
       fetch('http://localhost:8000/authenticate')
      .then(res => res.json())
      .then(res => {

  if (res.authenticate == true){
    return dispatch({
        type: "SET_USER",
        payload : {
            userName:userName,
            userType: "driver"
        }
    })
}
else {
    return dispatch({
        type: "SET_USER",
        payload : {
            userName:"",
            userType: ""
        }
    })
}
})


}