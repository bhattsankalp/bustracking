import React,{Component} from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import App from './App';
import Homepage from './components/Homepage.js'
import Allbuses from './components/Allbuses.js'
import RegisterUser from './components/RegisterUser.js'
 import GetBusStatus from './components/GetBusStatus.js'
import Topbar from './Topbar';
import {connect} from 'react-redux'
import Logout from './Logout'


class AppRoute extends Component{

    render(){
        return(
            <React.Fragment>
         
        {this.props.userType!=="" ? 
        <Router>
      < Route exact path="/">
      <App />
      </Route>
      < Route exact path="/login">
      <App />
      </Route>
      < Route exact path="/homePage">
      <Homepage />
      </Route>
      < Route exact path="/allbuses">
      <Allbuses />
      </Route>
      < Route exact path="/register">
      <RegisterUser />
      </Route>
    
      < Route exact path="/logout">
            <Logout />
            </Route>

      </Router>

      :

      <Router>
      < Route >
    <App />
    </Route>
    < Route exact path="/register">
      <RegisterUser />
      </Route>
    < Route exact path="/login">
    <App />
    </Route>
    </Router>
  
        }
          </React.Fragment>
        )
    }
}


const mapStateToProps = (state) => {
      
    return ({
      userName: state.userSelect.userName,
      userType : state.userSelect.userType
    })
  }
  
export default connect(mapStateToProps)(AppRoute)