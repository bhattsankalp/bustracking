export const userSelect = (state={userName: "userA",userType: "Driver",partnerName:""}, action) => {


    switch(action.type) {
        case "SET_USER" :
            return{
                ...state,
                userName : action.payload.userName,
                userType : action.payload.userType
            }

            case "SELECT_PARTNER" :
            return{
                ...state,
                partnerName : action.payload.partnerName
            }

            case "LOGOUT" :
                state={userName: "",userType: "",partnerName:""}
                return state
                    
            case "default" : return state

    }
    return state
}