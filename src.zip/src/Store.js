import {createStore ,combineReducers,applyMiddleware} from 'redux'
import thunk from 'redux-thunk'
import {userSelect} from './reducers/userSelect'

const rootReducer = combineReducers({
    userSelect : userSelect
})


function saveToLocalStorage(state){
    try{
        const serialisedState = JSON.stringify(state)
        localStorage.setItem('state', serialisedState)
    }
    catch(e){
        return undefined
    }
    }

    function loadFromLocalStorage(){
        try{
            const serialisedState = localStorage.getItem('state')
            if(serialisedState  === null) return undefined
            return JSON.parse(serialisedState)
        }catch(e){
            return undefined
        }

    }

    const persistedState = loadFromLocalStorage()
    const initialState = {}

    const Store = createStore(rootReducer,persistedState,applyMiddleware(thunk))

    Store.subscribe(() => saveToLocalStorage(Store.getState()))

    export default Store

