import React,{Component} from "react";
import {setUser} from './actions/setUser'
import {logoutAction} from './actions/logoutAction'
import {connect} from 'react-redux'
import {withRouter} from 'react-router-dom'

class Logout extends Component{

    componentDidMount(){
      this.props.logoutAction()
      this.props.history.push("/login")
       
    }
render(){
  return(
    <div></div>
  )
}
}

const mapStateToProps = (state) => {
    return ({
      userName: state.userSelect.userName,
      userType : state.userSelect.userType
    })
  }

  const mapDispatchToProps = (dispatch) => {
return({
  logoutAction : () => {
        dispatch(logoutAction())
    } 
})

  }

 
export default withRouter(connect(mapStateToProps,mapDispatchToProps) (Logout)) 