

import React,{Component} from 'react'
import './SearchByRoute.css';
import { MDBDataTableV5, MDBTableBody, MDBTableHead } from 'mdbreact';
import { FaEye } from "react-icons/fa";
import { withRouter } from 'react-router-dom';
import Topbar from '../Topbar';
import {connect} from 'react-redux'
import { Link } from 'react-router-dom'
import {OverlayTrigger,Tooltip,Breadcrumb,Col,Form,Row} from 'react-bootstrap';

class SearchByRoute extends Component {

    constructor(){
        super()
        this.state={
            userData:{},
            site_id:"",
            site_name:"",
            site_URL: "",
            buses: [],
            selectedRoute:""
        }
    }
componentDidMount(){
var rows
var columns
    
    
fetch('http://localhost:8000/getAllbuses')
.then(res => res.json())
.then((res) => {

    if(res[0]){

              columns = [
                { label: 'View Buses',
                field: 'viewBuses',
                width: 200,
               
              },
             { label: 'Route Id',
                    field: 'routeId',
                    width: 100,
                   
                  },
                  { label: 'Route',
                      field: 'route',
                      width: 200
                    }]

                    rows =  res.map(value => {
                      return({ 
                        viewBuses: <FaEye  className="PreviewIcons_reportTable" onClick={e =>  this.getBuses(value.routeId,"unselected") } />, 
                        routeId : value.bus.routeId,
                        route : value.route.route,
                        status:"unselected"
                         
                   })
                  }) 

                  this.setState({
                    userData: {
                      rows:rows,
                      columns:columns
                    },
                
                    showUserData:true
                  })
                  }
})
}

getBuses = (routeID,status) => {
    var userData
    var userDataColumns
    var updatedUserData
    if(status!=="selected"){
 userData = this.state.userData
 userDataColumns = userData.columns
 updatedUserData  = userData.rows.map(value => {
    if(value.routeId === routeID && value.status !=="selected" ){
        return({ 
            viewBuses: <FaEye  as={Link} className="PreviewIcons_reportTableActive" onClick={e =>  this.getBuses(value.routeId,"selected") } />, 
            routeId : value.routeId,
            route : value.route,
            status:"selected"
             
       })
    }
       else {
        return({ 
            viewBuses: <FaEye  as={Link} className="PreviewIcons_reportTable" onClick={e =>  this.getBuses(value.routeId,"unselected") } />, 
            routeId : value.routeId,
            route : value.route,
            status:"unselected"
       })
       }
    
})


fetch('http://localhost:8000/getAllbuses' )
.then(res => res.json())
.then((res) => {
let buses = res.map(row => {
    return row.bus.busId
})

this.setState({
    userData: {
        rows:updatedUserData,
        columns:userDataColumns
      },
  
      buses: buses,
      selectedRoute:routeID
    })
})

}
else {

     userData = this.state.userData
 userDataColumns = userData.columns
 updatedUserData  = userData.rows.map(value => {
  
        return({ 
            viewBuses: <FaEye  as={Link} className="PreviewIcons_reportTable" onClick={e =>  this.getBuses(value.routeId,"unselected") } />, 
            routeId : value.routeId,
            route : value.route,
            status:"unselected"
       })
    })
       
    

this.setState({
    userData: {
        rows:updatedUserData,
        columns:userDataColumns
      },
    buses:[],
    selectedRoute:""
})

}


}

    render(){
return(
    <div className="graysectionBg">
    <Topbar />

<Breadcrumb>
<Breadcrumb.Item href="/homePage">Home</Breadcrumb.Item>
<Breadcrumb.Item active>Search bus by route</Breadcrumb.Item>
</Breadcrumb>
{this.state.showUserData ? 
<div className="userResponseContent" >
<h5 className="subHeadings">Choose a route to see the buses</h5>



<Col sm={{span:8,offset:2}}>
<MDBDataTableV5
hover
striped 
bordered
style={{textAlign:'center'}}
 pagingTop
 searchTop
 scrollX
 scrollY

 maxHeight="25rem"
 searchBottom={false}
 data={this.state.userData}

/>
</Col>
{this.state.selectedRoute ?
<div>
<h5 className="subHeadings"><Row>You selected route : <p className="selectedRoute">&nbsp;&nbsp;{this.state.selectedRoute}</p></Row></h5>
<Form.Group>
    <Row>
    <Col sm={1}></Col>
        <Col sm={1}>
        <Form.Label className="mt-2 busLabel"  >Buses</Form.Label>
        </Col>
        <Col sm={8}>
        <Form.Control type="text" value={this.state.buses.toString()} />
        
           
        </Col>
        </Row> 
        </Form.Group>
           </div>
: null}
</div>
: null }
</div>
)
    }
}

const mapStateToProps = (state) => {

    return ({
    
    userName : state.userSelect.userName
    })
  }

    export default withRouter(connect(mapStateToProps) (SearchByRoute))