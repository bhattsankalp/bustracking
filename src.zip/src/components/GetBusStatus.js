import React,{Component} from 'react'
import './GetBusStatus.css';
import {OverlayTrigger,Tooltip,Breadcrumb,Col,Form,Row,ListGroup,InputGroup} from 'react-bootstrap';
import { withRouter } from 'react-router-dom';
import Topbar from '../Topbar';
import {connect} from 'react-redux'
import { FaSearch,FaRegArrowAltCircleRight } from "react-icons/fa";

class GetBusStatus extends Component {

    constructor(){
        super()
        this.state={
          coveredStations:[],
          unCoveredStations:[],
          showStatus:false,
          busId:""
        }
    }


onChangeHandler = (event) => {
    let nam = event.target.name;
    let val = event.target.value;
    this.setState({[nam]: val});
}

getStatus = () => {
    var requestData = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ busId:this.state.busId
        })
      }

    fetch('http://localhost:8000/busStatus')
    .then(res => res.json())
    .then((res) => {
    
        if(res){
    
                      this.setState({
                        coveredStations:res.covered,
              unCoveredStations:res.uncovered,
              showStatus:true
                      })
                      }
    })
}

    render(){
return(
    <div className="graysectionBg">
    <Topbar />

<Breadcrumb>
<Breadcrumb.Item href="/homePage">Home</Breadcrumb.Item>
<Breadcrumb.Item active>Bus Status</Breadcrumb.Item>
</Breadcrumb>


<div className="userResponseContent" >
<h5 className="subHeadings">Enter a bus id to see the status</h5>
<Form.Group>
    <Row>
    <Col sm={1}></Col>
        <Col sm={1}>
        <Form.Label className="mt-2 busLabel"  >Bus Id</Form.Label>
        </Col>
        <Col sm={8}>
        <InputGroup>
                          
                            <Form.Control type="text" name="busId" value={this.state.busId} onChange = {e => this.onChangeHandler(e)}  />
                            <InputGroup.Append>
                                <InputGroup.Text>
                                    <FaSearch  className="searchIcon" onClick= {e => this.getStatus()}/>
                                </InputGroup.Text>
                            </InputGroup.Append>
                        </InputGroup>
        
        
           
        </Col>
        </Row> 
        </Form.Group>
        {this.state.showStatus ? 
        <Col sm={{span:8,offset:2}} className="mt-5 mb-5">
<ListGroup horizontal> 
    {this.state.coveredStations.map (station => {
         return <ListGroup.Item className="coveredStations">{station}</ListGroup.Item>
         
    })}

{this.state.unCoveredStations.map ((station,index) => {
     return this.props.userType ==='Driver' && index===0 ? 
           <ListGroup.Item className="uncoveredStations">{station}</ListGroup.Item>
          :   <ListGroup.Item className="uncoveredStations">{station}</ListGroup.Item>
    })}
   
  </ListGroup>
  </Col>
: null }
</div>

</div>
)
    }
}

const mapStateToProps = (state) => {

    return ({
    
    userName : state.userSelect.userName,
    userType : state.userSelect.userType,
    })
  }

    export default withRouter(connect(mapStateToProps) (GetBusStatus))