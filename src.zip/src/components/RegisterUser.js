import React, { Component } from 'react'
import { Form, Col, Button,Breadcrumb } from 'react-bootstrap'
import './RegisterUser.css'
import Topbar from '../Topbar'
 
export class RegisterUser extends Component {
    constructor(props){
        super(props);
        this.state={
            userId: "",
            password:"",
            userName:"",
            firstName:"",
            lastName:"",
            phone:"",
            email: "",
            roleId:""
        }
    }
 
    myChangeHandler = (event) => {
        let nam = event.target.name;
        let val = event.target.value;
        this.setState({[nam]: val});
      }
 

 
    saveData = () => {
      const dataSource = {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            userId: this.state.userId,
            password:this.state.password,
            userName:this.state.userName,
            firstName:this.state.firstName,
            lastName:this.state.lastName,
            phone:this.state.phone,
            email: this.state.email,
            roleId:this.state.roleId
           })}
        fetch('http://localhost:8080/dataSource',dataSource)
        .then(res => res.json())
        .then((res) => {
           console.log("Success")
        })
    }
    render() {
        return (
            <div className="registerPage ">
              
            <Breadcrumb>
            <Breadcrumb.Item href="/login">Login</Breadcrumb.Item>
            
            <Breadcrumb.Item active>Register a user</Breadcrumb.Item>
            </Breadcrumb>
            <Col className="formApi" sm={{span:10,offset:1}}>
            <h5 className="subHeadings" sm={{span:2}}>Register</h5> 
 
            <Form.Group className="dbmenu">
            <Form.Group>
            <Form.Label>User Id</Form.Label>
            <Form.Control type="text" name="userId" onChange={e => this.myChangeHandler(e)}/>
           </Form.Group>

           <Form.Group>
            <Form.Label>Password</Form.Label>
            <Form.Control type="password" name="password" onChange={e => this.myChangeHandler(e)}/>
           </Form.Group>

           <Form.Group>
            <Form.Label>User Name</Form.Label>
            <Form.Control type="text" name="userName" onChange={e => this.myChangeHandler(e)}/>
           </Form.Group>

           <Form.Group>
            <Form.Label>First Name</Form.Label>
            <Form.Control type="text" name="firstName" onChange={e => this.myChangeHandler(e)}/>
           </Form.Group>
           <Form.Group>
            <Form.Label>Last Name</Form.Label>
            <Form.Control type="text" name="lastName" onChange={e => this.myChangeHandler(e)}/>
           </Form.Group>
           <Form.Group>
            <Form.Label>Phone</Form.Label>
            <Form.Control type="number" name="phone" onChange={e => this.myChangeHandler(e)}/>
           </Form.Group>
           <Form.Group>
            <Form.Label>Email</Form.Label>
            <Form.Control type="email" name="email" onChange={e => this.myChangeHandler(e)}/>
           </Form.Group>
           <Form.Group>
            <Form.Label>Role Id</Form.Label>
            <Form.Control type="roleId" name="text" onChange={e => this.myChangeHandler(e)}/>
           </Form.Group>
           
           </Form.Group>
          
 
         
 
           
           
           <Button className="btn-primary ml-0" block onClick={e => this.saveData()} variant="outline-secondary">Save</Button>
 
            </Col>
            </div>
        )
    }
}
 
export default RegisterUser