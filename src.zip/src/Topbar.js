import React,{Component} from 'react'
import Navbar from "react-bootstrap/Navbar"
import { Button,Nav,Form,FormControl,Col,OverlayTrigger,Tooltip} from 'react-bootstrap'
import {connect} from 'react-redux'
import { FaUser,FaBell,FaPen } from "react-icons/fa";
class Topbar extends Component {

render(){
    return(

    
<Navbar fixed-top collapseOnSelect expand="lg"  variant="dark" style={{backgroundColor:"#000"}} >
<Navbar.Brand ><img src="../busLogo.png" style={{width:50,height:50}}/></Navbar.Brand>
<Navbar.Brand href="/" ><b>My Bus</b></Navbar.Brand>
<Navbar.Toggle aria-controls="responsive-navbar-nav" />
{this.props.userType ?
  <Nav className="ml-auto" variant="dark" >
<OverlayTrigger trigger="click" placement="bottom" 
  overlay={  
    <Tooltip id="blue-tooltip" style={{backgroundColor:"#343a40"}}>
    <Nav.Link  style={{color:"white",backgroundColor:"#343a40"}}><FaPen />&nbsp;Change Password</Nav.Link>
<Nav.Link href="logout" style={{color:"white",backgroundColor:"#343a40"}}><FaBell />&nbsp;LogOut</Nav.Link>
</Tooltip>
  }>
  <Nav.Link >
    <Col style={{color:"white",fontSize:"small"}}><FaUser />&nbsp;Hi {this.props.userName}</Col>
    <Col style={{color:"white",fontSize:"small"}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>({this.props.userType})</u></Col>
    </Nav.Link>
  </OverlayTrigger>
  </Nav>
 : null}
  

</Navbar>
        
    )
}

}

const mapStateToProps = (state) => {
   
  return ({
    userName: state.userSelect.userName,
    userType : state.userSelect.userType
  })
}

export default connect(mapStateToProps)(Topbar)

